package main


type NikeShirt struct {
    Shirt
}